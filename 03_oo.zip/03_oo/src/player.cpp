#include "player.hpp"

Player::Player(Color color) : color(color) {}

Player::~Player() {}
