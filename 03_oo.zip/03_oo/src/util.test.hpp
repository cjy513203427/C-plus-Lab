#pragma once

#include "player.hpp"

void test_single_move(Player& player, Field expectedField);
